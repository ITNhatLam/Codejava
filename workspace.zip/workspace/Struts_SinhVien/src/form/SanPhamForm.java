package form;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import model.bean.Loai;
import model.bean.SanPham;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

public class SanPhamForm extends ActionForm {
	private String maSP;
	private String tenSP;
	private String nhaSX;
	private String tenLoai;
	private String maLoai;
	private String nhaPP;
	private String action;
	private ArrayList<Loai> listLoai;
	private String submit;
	private SanPham sp;
	public String getMaSP() {
		return maSP;
	}
	public void setMaSP(String maSP) {
		this.maSP = maSP;
	}
	public String getTenSP() {
		return tenSP;
	}
	public void setTenSP(String tenSP) {
		this.tenSP = tenSP;
	}
	public String getNhaSX() {
		return nhaSX;
	}
	public void setNhaSX(String nhaSX) {
		this.nhaSX = nhaSX;
	}
	public String getTenLoai() {
		return tenLoai;
	}
	public void setTenLoai(String tenLoai) {
		this.tenLoai = tenLoai;
	}
	public String getNhaPP() {
		return nhaPP;
	}
	public void setNhaPP(String nhaPP) {
		this.nhaPP = nhaPP;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public ArrayList<Loai> getListLoai() {
		return listLoai;
	}
	public void setListLoai(ArrayList<Loai> listLoai) {
		this.listLoai = listLoai;
	}
	public String getSubmit() {
		return submit;
	}
	public void setSubmit(String submit) {
		this.submit = submit;
	}
	public SanPham getSp() {
		return sp;
	}
	public void setSp(SanPham sp) {
		this.sp = sp;
	}
	
	public String getMaLoai() {
		return maLoai;
	}
	public void setMaLoai(String maLoai) {
		this.maLoai = maLoai;
	}
	@Override
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
