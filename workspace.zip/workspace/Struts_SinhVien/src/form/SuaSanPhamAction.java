package form;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.bean.Loai;
import model.bean.SanPham;
import model.bo.LoaiBO;
import model.bo.SanPhamBO;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public class SuaSanPhamAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		request.setCharacterEncoding("UTF-8");
		SanPhamForm sanPhamForm = (SanPhamForm) form;

		SanPhamBO sanPhamBO = new SanPhamBO();
		//lay danh sach cac khoa
		LoaiBO loaiBO = new LoaiBO();
		ArrayList<Loai> listLoai = loaiBO.getListLoai();
		sanPhamForm.setListLoai(listLoai);
		
		//sua sinh vien
		String msp=sanPhamForm.getMaSP();
		if("submit".equals(sanPhamForm.getSubmit())){					//nhan nut Xac nhan o trang Them sinh vien
			String hoTen= sanPhamForm.getTenSP();
			String nhaSX=sanPhamForm.getNhaSX();
			String maLoai=sanPhamForm.getMaLoai();
			String nhaPP=sanPhamForm.getMaSP();
			sanPhamBO.suaSanPham(msp, hoTen, nhaSX, maLoai, nhaPP);
			return mapping.findForward("suaSVxong");
		} else {														//chuyen sang trang Sua sinh vien
			SanPham sanPham = sanPhamBO.getThongTinSanPham(msp);
			sanPhamForm.setTenSP(sanPham.getTenSP());
			sanPhamForm.setNhaSX(sanPham.getNhaSX());
			sanPhamForm.setTenLoai(sanPham.getTenLoai());
			sanPhamForm.setNhaPP(sanPham.getNhaPP());
			return mapping.findForward("suaSV");
		}
	}
}
