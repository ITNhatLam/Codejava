package form;

import java.util.ArrayList;

import model.bean.Loai;
import model.bean.SanPham;

import org.apache.struts.action.ActionForm;

/**
 * 
 * @author HCD-Fresher030
 *
 */
public class DanhSachSanPhamForm extends ActionForm{
	private String maLoai;
	private ArrayList<Loai> listLoai;
	private ArrayList<SanPham> listSanPham;
	public String getMaLoai() {
		return maLoai;
	}
	public void setMaLoai(String maLoai) {
		this.maLoai = maLoai;
	}
	public ArrayList<Loai> getListLoai() {
		return listLoai;
	}
	public void setListLoai(ArrayList<Loai> listLoai) {
		this.listLoai = listLoai;
	}
	public ArrayList<SanPham> getListSanPham() {
		return listSanPham;
	}
	public void setListSanPham(ArrayList<SanPham> listSanPham) {
		this.listSanPham = listSanPham;
	}
	
	
}
