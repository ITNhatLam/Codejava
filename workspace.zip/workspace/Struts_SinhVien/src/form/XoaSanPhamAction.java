package form;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.bean.Loai;
import model.bean.SanPham;
import model.bo.LoaiBO;
import model.bo.SanPhamBO;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public class XoaSanPhamAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		request.setCharacterEncoding("UTF-8");
		SanPhamForm sanPhamForm = (SanPhamForm) form;

		SanPhamBO sanPhamBO = new SanPhamBO();
		//lay danh sach cac khoa
		LoaiBO loaiBO = new LoaiBO();
		ArrayList<Loai> listLoai = loaiBO.getListLoai();
		sanPhamForm.setListLoai(listLoai);
		
		//xoa sinh vien
		String msp=sanPhamForm.getMaSP();
		if("submit".equals(sanPhamForm.getSubmit())){			//nhan nut Xac nhan o trang Xoa sinh vien
			sanPhamBO.xoaSanPham(msp);
			return mapping.findForward("xoaSPxong");
		} else {													//chuyen sang trang Xoa sinh vien
			SanPham sanPham = sanPhamBO.getThongTinSanPham(msp);
			sanPhamForm.setTenSP(sanPham.getTenSP());
			sanPhamForm.setNhaSX(sanPham.getNhaSX());
			sanPhamForm.setTenLoai(sanPham.getTenLoai());
			sanPhamForm.setNhaPP(sanPham.getNhaPP());
			return mapping.findForward("xoaSP");
		}
	}
}
