package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.bean.Loai;
import model.bo.LoaiBO;
import model.bo.SanPhamBO;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;

import common.StringProcess;

import form.SanPhamForm;



public class ThemSanPhamAction extends Action{

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		request.setCharacterEncoding("UTF-8");
		SanPhamForm sanPhamForm = (SanPhamForm) form;
		//lay danh sach cac khoa
		LoaiBO khoaBO = new LoaiBO();
		ArrayList<Loai> listLoai = khoaBO.getListLoai();
		sanPhamForm.setListLoai(listLoai);
		
		//validate du lieu
		if("submit".equals(sanPhamForm.getSubmit())){
			ActionErrors actionErrors = new ActionErrors();
			if(StringProcess.notVaild(sanPhamForm.getMaSP())){
				actionErrors.add("maSPError", new ActionMessage("error.msv.trong"));
			}
			if(StringProcess.notVaildNumber(sanPhamForm.getMaSP())){
				actionErrors.add("maSPError", new ActionMessage("error.msv.so"));
			}
			saveErrors(request, actionErrors);
			if(actionErrors.size()>0){
				return mapping.findForward("themSPerror");
			}
		}
		if("submit".equals(sanPhamForm.getSubmit())){		//nhan nut Xac nhan o trang Them sinh vien
			String maLoai = sanPhamForm.getMaLoai();
			String maSP = sanPhamForm.getMaSP();
			String tenSP= sanPhamForm.getTenSP();
			String nhaSX=sanPhamForm.getNhaSX();
			String nhaPP=sanPhamForm.getNhaPP();
			SanPhamBO sanPhamBO = new SanPhamBO();
			sanPhamBO.themSanPham(maSP, tenSP, nhaSX, maLoai, nhaPP);
			return mapping.findForward("themSPxong");
		} else {											//chuyen sang trang Them sinh vien
			return mapping.findForward("themSP");
		}
	}
	
}
