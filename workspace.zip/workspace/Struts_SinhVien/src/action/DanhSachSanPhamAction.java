package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.bean.Loai;
import model.bean.SanPham;
import model.bo.LoaiBO;
import model.bo.SanPhamBO;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.DanhSachSanPhamForm;


public class DanhSachSanPhamAction extends Action{

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		DanhSachSanPhamForm nguoiDungForm = (DanhSachSanPhamForm) form;
		
		//lay danh sach cac khoa
		LoaiBO loaiBO = new LoaiBO();
		ArrayList<Loai> listLoai = loaiBO.getListLoai();
		nguoiDungForm.setListLoai(listLoai);
		
		//lay danh sach sinh vien
		ArrayList<SanPham> listSanPham;
		SanPhamBO sanPhamBO = new SanPhamBO();
		String maLoai=nguoiDungForm.getMaLoai();
		if(maLoai==null || maLoai.length()==0){
			listSanPham = sanPhamBO.getListSanPham();
		} else {
			listSanPham = sanPhamBO.getListSanPham(maLoai);
		}
		nguoiDungForm.setListSanPham(listSanPham);
		return mapping.findForward("dsSanPham");
	}
	
}
