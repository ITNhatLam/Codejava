package model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.bean.SanPham;



public class SanPhamDAO {
	String url = "jdbc:sqlserver://localhost:1433;databaseName=BanHang";
	String userName = "sa";
	String password = "12345678";
	Connection connection;
	void connect(){
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			connection = DriverManager.getConnection(url, userName, password);
			System.out.println("Ket noi thanh cong");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Ket noi loi");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("Ket noi loi");
		}
	}
	public ArrayList<SanPham> getListSanPham(){
		connect();
		String sql=	"select sp.MaSP,sp.TenSP,sp.NhaSX,sp.NhaPP,lo.TenLoai from SanPham sp join Loai lo on sp.MaLoai=lo.MaLoai";
		ResultSet rs = null;
		try {
		Statement stmt = connection.createStatement();
		rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
		e.printStackTrace();
		}
		
		ArrayList<SanPham> list = new ArrayList<SanPham>();
		SanPham sp;
		try {
		while(rs.next()){
			sp = new SanPham();
			sp.setMaSP(rs.getString("MaSP"));
			sp.setTenSP(rs.getString("TenSP"));
			sp.setNhaSX(rs.getString("NhaSX"));
			sp.setTenLoai(rs.getString("TenLoai"));
			sp.setNhaPP(rs.getString("NhaPP"));
			list.add(sp);
		}
		} catch (SQLException e) {
		e.printStackTrace();
		}
		return list;
	}
	
	public ArrayList<SanPham> getListSanPham(String maLoai) {
		connect();
		String sql=	String.format("select sp.MaSP,sp.TenSP,sp.NhaSX,sp.NhaPP,lo.TenLoai from SanPham sp join Loai lo on sp.MaLoai=lo.MaLoai where sp.MaLoai='%s'", maLoai);
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<SanPham> list = new ArrayList<SanPham>();
		SanPham sp;
		try {
		while(rs.next()){
			sp = new SanPham();
			sp.setMaSP(rs.getString("MaSP"));
			sp.setTenSP(rs.getString("TenSP"));
			sp.setNhaSX(rs.getString("NhaSX"));
			sp.setTenLoai(rs.getString("TenLoai"));
			sp.setNhaPP(rs.getString("NhaPP"));
			list.add(sp);
		}
		} catch (SQLException e) {
		e.printStackTrace();
		}
		return list;
	}
	public void themSanPham(String msp, String tenSP, String nhaSX, String maLoai, String nhaPP) {
		connect();
		String sql=	String.format("insert into SanPham(MaSP,TenSP,NhaSX,MaLoai,NhaPP)"+
					" VALUES ( '%s',N'%s',N'%s','%s' ,N'%s')", msp, tenSP, nhaSX, maLoai,nhaPP);
		try {
			Statement stmt = connection.createStatement();
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public SanPham getThongTinSanPham(String msp) {
		connect();
		String sql=	String.format("SELECT MaSP, TenSP, NhaSX, MaLoai, NhaPP "+
					" FROM SanPham WHERE MaSP = '%s'", msp);
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		SanPham sp = new SanPham();
		try {
			while(rs.next()){
				sp.setMaSP(msp);
				sp.setTenSP(rs.getString("TenSP"));
				sp.setNhaSX(rs.getString("NhaSX"));
				sp.setMaLoai(rs.getString("MaLoai"));
				sp.setNhaPP(rs.getString("NhaPP"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return sp;
	}

	public void suaSanPham(String msp, String tenSP, String nhaSX, String maLoai, String nhaPP) {
		connect();
		String sql=	String.format("UPDATE SanPham "+
					" SET TenSP = N'%s', NhaSX = N'%s', MaLoai = '%s', NhaPP= N'%s' " +
					" WHERE MaSP = '%s'", tenSP, nhaSX, maLoai, nhaPP);
		try {
			Statement stmt = connection.createStatement();
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void xoaSanPham(String msp) {
		connect();
		String sql=	String.format("DELETE FROM SanPham WHERE MaSP = '%s'", msp);
		System.out.println(sql);
		try {
			Statement stmt = connection.createStatement();
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
