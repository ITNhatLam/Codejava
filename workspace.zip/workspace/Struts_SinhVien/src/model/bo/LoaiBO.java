package model.bo;

import java.util.ArrayList;

import model.bean.Loai;
import model.dao.LoaiDAO;


public class LoaiBO {
	LoaiDAO loaiDAO = new LoaiDAO();

	public ArrayList<Loai> getListLoai() {
		return loaiDAO.getListLoai();
	}
}
