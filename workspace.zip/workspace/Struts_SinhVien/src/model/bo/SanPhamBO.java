package model.bo;

import java.util.ArrayList;

import model.bean.SanPham;
import model.dao.SanPhamDAO;

public class SanPhamBO {
	SanPhamDAO sanPhamDAO = new SanPhamDAO();
	public ArrayList<SanPham> getListSanPham(){
		return sanPhamDAO.getListSanPham();
	}
	public  ArrayList<SanPham> getListSanPham(String maLoai){
		return sanPhamDAO.getListSanPham(maLoai);
	}
	public void themSanPham(String msp, String tenSP, String nhaSX, String maLoai, String nhaPP) {
		sanPhamDAO.themSanPham(msp, tenSP, nhaSX, maLoai, nhaPP);
	}
	public SanPham getThongTinSanPham(String msp) {
		return sanPhamDAO.getThongTinSanPham(msp);
	}
	public void suaSanPham(String msp, String tenSP, String nhaSX, String maLoai, String nhaPP) {
		sanPhamDAO.suaSanPham(msp, tenSP, nhaSX, maLoai, nhaPP);
	}
	public void xoaSanPham(String msp) {
		sanPhamDAO.xoaSanPham(msp);
	}
}
