package model.bean;

public class SanPham {
	private String maSP;
	private String tenSP;
	private String nhaSX;
	private String maLoai;
	private String tenLoai;
	private String nhaPP;
	public String getMaSP() {
		return maSP;
	}
	public void setMaSP(String maSP) {
		this.maSP = maSP;
	}
	public String getTenSP() {
		return tenSP;
	}
	public void setTenSP(String tenSP) {
		this.tenSP = tenSP;
	}
	public String getNhaSX() {
		return nhaSX;
	}
	public void setNhaSX(String nhaSX) {
		this.nhaSX = nhaSX;
	}
	public String getMaLoai() {
		return maLoai;
	}
	
	public String getTenLoai() {
		return tenLoai;
	}
	public void setTenLoai(String tenLoai) {
		this.tenLoai = tenLoai;
	}
	public void setMaLoai(String maLoai) {
		this.maLoai = maLoai;
	}
	public String getNhaPP() {
		return nhaPP;
	}
	public void setNhaPP(String nhaPP) {
		this.nhaPP = nhaPP;
	}
	
}
