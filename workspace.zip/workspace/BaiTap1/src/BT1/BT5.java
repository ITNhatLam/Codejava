package BT1;

import java.util.Scanner;

public class BT5 {
	static double giaithua(double x)
	{
		double P=1;
		for(float i=1;i<=x;i++)
		{
			P=P*i;
		}
		return P;
	}
public static void main(String[] args) {
	Scanner input= new Scanner(System.in);
	System.out.println("Nhap n:");
	int n;
	n=input.nextInt();
	float S=0;
	for(float i=1;i<=n;i++)
	{
		S+=1/giaithua(2*i-1);
	}
	System.out.println("Tong la"+S);
}
}
