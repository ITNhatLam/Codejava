package BT1;

import java.util.Scanner;

public class BT2 {
public static void main(String[] args) {
	Scanner input=new Scanner(System.in);
	System.out.println("");
}
}
