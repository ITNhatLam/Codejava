package BT1;

import java.util.Scanner;

public class bt1 {
	public static void main(String[] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Nhap n:");
		int n;
		n=input.nextInt();
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=i;j++)
			System.out.print("*");
			System.out.print("\n");
		}
		
	}
}
