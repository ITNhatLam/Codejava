package BT1;

import java.util.Scanner;

public class BT6 {
public static void main(String[] args) {
	Scanner input= new Scanner(System.in);
	double n;
	n=input.nextDouble();
	double P1=1;
	if(n%2==0)
	{
		
		for(int i=2;i<=n;i++)
		{
			P1=P1*i;
			System.out.println("P="+P1);
		}
	}
	else
	{
		for(int i=1;i<=n;i++)
		{
			P1=P1*i;
			System.out.println("P="+P1);
		}
	}
}
}
