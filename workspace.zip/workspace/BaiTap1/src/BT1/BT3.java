package BT1;

import java.util.Scanner;

public class BT3 {
public static void main(String[] args) {
	Scanner input= new Scanner(System.in);
	System.out.println("Nhap n:");
	int n;
	n=input.nextInt();
	float S=1;
	for(float i=2;i<=n;i++)
	{
		S=S+1/i;
	}
	System.out.print("S=");
	System.out.println(S);
}
}
