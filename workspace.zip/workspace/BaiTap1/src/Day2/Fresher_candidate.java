package Day2;

import java.util.Date;

public class Fresher_candidate extends Candidate{
	private Date graduation_date;
	private String graduation_rank;
	private String education;
	
	public Fresher_candidate()
	{
		
	}
	public Fresher_candidate(Date graduation_date, String graduation_rank, String education)
	{
		super();
		this.graduation_date = graduation_date;
		this.graduation_rank = graduation_rank;
		this.education = education;
	}
	public Date getGraduation_date() {
		return graduation_date;
	}
	public void setGraduation_date(Date graduationDate) {
		graduation_date = graduationDate;
	}
	public String getGraduation_rank() {
		return graduation_rank;
	}
	public void setGraduation_rank(String graduationRank) {
		graduation_rank = graduationRank;
	}
	public String getEducation() {
		return education;
	}
	public void setEducation(String education) {
		this.education = education;
	}
	
}
