package Day2;

public class Intern_candidate extends Candidate{
	
	private String majors;
	private int semester;
	private String university_name;
	
	public Intern_candidate()
	{
		
	}
	public Intern_candidate(String majors, int semester, String university_name)
	{
		super();
		this.majors = majors;
		this.semester = semester;
		this.university_name=university_name;
	}
	public String getMajors() {
		return majors;
	}
	public void setMajors(String majors) {
		this.majors = majors;
	}
	public int getSemester() {
		return semester;
	}
	public void setSemester(int semester) {
		this.semester = semester;
	}
	public String getUniversity_name() {
		return university_name;
	}
	public void setUniversity_name(String universityName) {
		university_name = universityName;
		
	}
	
}
