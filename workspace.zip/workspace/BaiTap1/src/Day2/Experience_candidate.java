package Day2;

public class Experience_candidate extends Candidate{
	private int expInYear;
	private String proSkill;
	
	public Experience_candidate(){
		
	}
	
	public Experience_candidate(int expInYear, String proSkill){
		super();
		this.expInYear= expInYear;
		this.proSkill=proSkill;
		
	}

	public int getExpInYear() {
		return expInYear;
	}

	public void setExpInYear(int expInYear) {
		this.expInYear = expInYear;
	}

	public String getProSkill() {
		return proSkill;
	}

	public void setProSkill(String proSkill) {
		this.proSkill = proSkill;
	}
	
}
