package Day2;

import java.util.Scanner;

public class main {
	public static void main(String[] args)
	{
		DanhSachUngVien ds= new DanhSachUngVien();
		Scanner input=new Scanner(System.in);
		for(int i=0;i<ds.getLength();i++)
		{
			int type=0;
			do{
				System.out.println("Nhap LOai ung vien");
				System.out.println("0. Ung vien co kinh nghiem");
				System.out.println("1. Ung vien moi tot nghiep");
				System.out.println("2. Sinh vien thuc tap");
				type=input.nextInt();
				
			}
			while(type<0 && type>2);
			Candidate uv;
			switch(type)
			{
			case 0:
					uv = new Experience_candidate() ;
					Experience_candidate ex=new Experience_candidate();
					System.out.println("Nhap nam kinh nghem");
					ex.setExpInYear(input.nextInt());
					
			}
		}
	}
}
