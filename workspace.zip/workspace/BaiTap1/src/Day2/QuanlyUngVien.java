package Day2;

import java.util.Date;
import java.util.Scanner;

public class QuanlyUngVien {
public static void main(String[] args) {
	Scanner input= new Scanner(System.in);
	//Khoi tao 1 loai ung vien
	
	Candidate can = new Intern_candidate();
	//Intern_candidate in = new Intern_candidate();

	can.setFirstName("Lam");
	can.setLastName("Nguyen");
	can.setBirthDate(Date("80/08/1996"));
	can.setAddress("Nha Trang");
	can.setPhone("012456");
	can.setEmail("a.gmail.com");
	can.setCandidate_type(1);
	
	Intern_candidate in = new Intern_candidate();
	in.setMajors("CNTT");
	
	
	System.out.println("fname: "+can.getFirstName());
	System.out.println("LastName: "+can.getLastName());
	System.out.println("Birthdate: "+can.getBirthDate());
	System.out.println("major: "+in.getMajors());
	
	
	
}

private static Date Date(String string) {
	// TODO Auto-generated method stub
	return null;
}
}
