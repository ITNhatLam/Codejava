package Day2;

public interface dsUngvien {

}
