package Day2;

public class DanhSachUngVien {
	private Candidate[] dsUngvien;
	private int length;
	public Candidate[] getDsUngvien() {
		return dsUngvien;
	}
	public void setDsUngvien(Candidate[] dsUngvien) {
		this.dsUngvien = dsUngvien;
	}
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	public DanhSachUngVien(Candidate[] dsUngvien, int length) {
		super();
		this.dsUngvien = dsUngvien;
		this.length = length;
	}
	public DanhSachUngVien()
	{
//		this.dsUngvien=new dsUngvien[30];
		this.length=0;
	}
	public void add(Candidate can)
	{
		this.length++;
		this.dsUngvien[this.length]=can;
	}
}
