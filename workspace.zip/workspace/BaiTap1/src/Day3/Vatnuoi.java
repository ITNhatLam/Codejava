package Day3;

public abstract class Vatnuoi {
	private String tenVn;
	private String gioiTinh;
	private int canNang;
	private int tuoi;
	public String getTenVn() {
		return tenVn;
	}
	public void setTenVn(String tenVn) {
		this.tenVn = tenVn;
	}
	public String getGioiTinh() {
		return gioiTinh;
	}
	public void setGioiTinh(String gioiTinh) {
		this.gioiTinh = gioiTinh;
	}
	public int getCanNang() {
		return canNang;
	}
	public void setCanNang(int canNang) {
		this.canNang = canNang;
	}
	public int getTuoi() {
		return tuoi;
	}
	public void setTuoi(int tuoi) {
		this.tuoi = tuoi;
	}
	public Vatnuoi(String tenVn, String gioiTinh, int canNang, int tuoi) {
		super();
		this.tenVn = tenVn;
		this.gioiTinh = gioiTinh;
		this.canNang = canNang;
		this.tuoi = tuoi;
	}
	
	public abstract void keu();
}
