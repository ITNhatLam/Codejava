package Day3;

import java.util.ArrayList;

public class Khoitao{
	private ArrayList<Vatnuoi> chuong;
	public ArrayList<Vatnuoi> taoChuong(){
		chuong =new ArrayList<Vatnuoi>();
		Conbo cb1=new Conbo("Con bo", "Duc", 12,5);
		chuong.add(cb1);
		Conbo cb2= new Conbo("Con bo", "Duc", 50, 12);
		chuong.add(cb2);
		Conheo ch1= new Conheo("Con heo", "duc", 12, 24);
		chuong.add(ch1);
		return chuong;
	}
}
