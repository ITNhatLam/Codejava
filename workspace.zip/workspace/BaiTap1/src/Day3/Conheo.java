package Day3;

public class Conheo extends Vatnuoi{

	public Conheo(String tenVn, String gioiTinh, int canNang, int tuoi) {
		super(tenVn, gioiTinh, canNang, tuoi);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void keu() {
		// TODO Auto-generated method stub
		System.out.println("ec.... ec");
	}
	public void an()
	{
		System.out.println("an cam");
	}
}
