package Day3;

import java.util.ArrayList;

public class Demo {
	public static void main(String[] args) {
		Khoitao kt = new Khoitao();
		ArrayList<Vatnuoi> chuong= kt.taoChuong();
		for(int i=0;i<chuong.size();i++)
		{
			Vatnuoi con = chuong.get(i);
			System.out.println(con.toString());
			con.keu();
			if(con instanceof Conbo)
			{
				Conbo cb1=(Conbo) con;
				System.out.print("Con bo an: ");
				cb1.an();
				
			}
			else if(con instanceof Conheo)
			{
				Conheo conheo=(Conheo) con;
				System.out.print("Con heo an: ");
				conheo.an();
			}
		}
	}
}
