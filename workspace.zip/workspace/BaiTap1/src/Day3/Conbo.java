package Day3;

public class Conbo extends Vatnuoi{

	public Conbo(String tenVn, String gioiTinh, int canNang, int tuoi) {
		super(tenVn, gioiTinh, canNang, tuoi);
		// TODO Auto-generated constructor stub
	}

	public void keu() {
		// TODO Auto-generated method stub
		System.out.println("bo...bo");
	}
	public void an()
	{
		System.out.println("An co");
	}
	@Override
	public String toString() {
		return "Conbo [CanNang=" + getCanNang() + ", GioiTinh="
				+ getGioiTinh() + ", TenVn=" + getTenVn() + ", Tuoi="
				+ getTuoi()+"]";
	}
	

}
