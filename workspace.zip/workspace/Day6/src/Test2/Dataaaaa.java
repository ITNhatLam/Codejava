package Test2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Dataaaaa {
	Scanner input=new Scanner(System.in);
	Connection sqlcon=null;
	Statement stmt=null;
	ResultSet rs=null;
	public Connection getConnect(){
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			sqlcon=DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=Test; username=sa; password=12345678");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sqlcon;
	}
	
	
	public boolean updateUseRs(){

	try {
		stmt = getConnect().createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
                ResultSet.CONCUR_UPDATABLE);
		rs = stmt.executeQuery("Select MaBH, TenBH, LoaiBH, tuoi from BaoHiem");
		
		rs.beforeFirst();
		//STEP 7: Extract data from result set
		while(rs.next()){
			//Retrieve by column name
			int newAge = rs.getInt("tuoi") + 2;
			rs.updateDouble( "tuoi", newAge );
			rs.updateRow();
			
		}
		//System.out.println("List result set showing new ages...");
		//printRs(rs);
		return true;
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		
	}
	return false;
	}
	
	public void addUseRs() {
		try {
			stmt = getConnect().createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
			        ResultSet.CONCUR_UPDATABLE);
			rs = stmt.executeQuery("Select MaBH, TenBH, LoaiBH, tuoi from BaoHiem");
			System.out.println("Inserting a new record...");
			getConnect().setAutoCommit(false);
		      rs.moveToInsertRow();
		      
		      System.out.println("nhap ma bao hiem: ");
		      String ma=input.nextLine();
		      rs.updateString("MaBH",ma);
		      
		      System.out.println("nhap ten bao hiem: ");
		      String ten=input.nextLine();
		      rs.updateString("TenBH",ten);
		      
		      System.out.println("nhap loai bao hiem: ");
		      boolean loai=Boolean.parseBoolean(input.nextLine());
		      rs.updateBoolean("LoaiBH",loai);
		      
		      
		      System.out.println("nhap tuoi bao hiem: ");
		      int tuoi=Integer.parseInt(input.nextLine());
		      rs.updateInt("tuoi",tuoi);
		      
		      getConnect().commit();
		      
		      //Commit row
		      rs.insertRow();

		      System.out.println("List result set showing new set...");
		      printRs(rs);
		      getConnect().setAutoCommit(true);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			try {
				getConnect().rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		}	
	}
	public void delUseRs() throws SQLException{
		try {
				getConnect().setAutoCommit(false);
				stmt = getConnect().createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,
				        ResultSet.CONCUR_UPDATABLE);
				rs = stmt.executeQuery("Select MaBH, TenBH, LoaiBH, tuoi from BaoHiem ");
				 rs.absolute( 1);
			      System.out.println("List the record before deleting...");
			      //Retrieve by column name
			      String ma = rs.getString("MaBH");
			      String ten = rs.getString("TenBH");
			      boolean loai=rs.getBoolean("LoaiBH");
			      int tuoi=rs.getInt("tuoi");

			      //Display values
			      System.out.print("ID: " + ma);
			      System.out.print(", Age: " + ten);
			      System.out.print(", First: " + loai);
			      System.out.println(", Last: " + tuoi);

			     //Delete row
			      rs.deleteRow();
			      System.out.println("List result set after deleting one records...");
			      printRs(rs);
			      getConnect().commit();
			} catch (SQLException e) {
				
				// TODO Auto-generated catch block
				e.printStackTrace();
				getConnect().rollback();
			}
			
	}
	public static void printRs(ResultSet rs) throws SQLException{
	      //Ensure we start with first row
	      rs.beforeFirst();
	      while(rs.next()){
	         //Retrieve by column name
	         String ma  = rs.getString("MaBH");
	         String ten = rs.getString("TenBH");
	         boolean loai=rs.getBoolean("LoaiBH");
	         int tuoi = rs.getInt("tuoi");
	         
	         //Display values
	         System.out.println("Employee Name: " + ma);
	         System.out.println(", Phone: " + ten);
	         System.out.println(", Phone: " + loai);
	         System.out.println(", Age: " + tuoi);
	     }
	     System.out.println();
	   }

}
