package Test2;

import java.sql.SQLException;

import Test.DataAccess;

public class Appmain {
	public static void main(String[] args) {
		Dataaaaa db=new Dataaaaa();
		if(db.getConnect()!=null)
			System.out.println("thanh cong");
		else
			System.out.println("ko thanh cong");
		db.addUseRs();
//		if(db.updateUseRs()==true)
//			System.out.println("sua tuoi thanh cong");
//		else 
		//	System.out.println("sua ko thanh cong");
		//db.addUseRs();
		try {
			db.delUseRs();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
