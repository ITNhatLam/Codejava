package Test2;

public class BaoHiemTest {
	private String maBH;
	private String tenBH;
	private boolean loaiBH;
	private int tuoi;
	public BaoHiemTest(String maBH, String tenBH, boolean loaiBH, int tuoi) {
		super();
		this.maBH = maBH;
		this.tenBH = tenBH;
		this.loaiBH = loaiBH;
		this.tuoi = tuoi;
	}
	public String getMaBH() {
		return maBH;
	}
	public void setMaBH(String maBH) {
		this.maBH = maBH;
	}
	public String getTenBH() {
		return tenBH;
	}
	public void setTenBH(String tenBH) {
		this.tenBH = tenBH;
	}
	public boolean isLoaiBH() {
		return loaiBH;
	}
	public void setLoaiBH(boolean loaiBH) {
		this.loaiBH = loaiBH;
	}
	public int getTuoi() {
		return tuoi;
	}
	public void setTuoi(int tuoi) {
		this.tuoi = tuoi;
	}
	@Override
	public String toString() {
		return "BaoHiemTest [loaiBH=" + loaiBH + ", maBH=" + maBH + ", tenBH="
				+ tenBH + ", tuoi=" + tuoi + "]";
	}
	
}
