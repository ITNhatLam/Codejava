package Test;

import java.util.Date;

public class BaoHiem {
	private String maBH;
	private String tenBH;
	private boolean loaiBH;
	private Date ngay;
	public BaoHiem(String maBH, String tenBH, boolean loaiBH, Date ngay) {
		super();
		this.maBH = maBH;
		this.tenBH = tenBH;
		this.loaiBH = loaiBH;
		this.ngay = ngay;
	}
	public String getMaBH() {
		return maBH;
	}
	public void setMaBH(String maBH) {
		this.maBH = maBH;
	}
	public String getTenBH() {
		return tenBH;
	}
	public void setTenBH(String tenBH) {
		this.tenBH = tenBH;
	}
	public boolean isLoaiBH() {
		return loaiBH;
	}
	public void setLoaiBH(boolean loaiBH) {
		this.loaiBH = loaiBH;
	}
	public Date getNgay() {
		return ngay;
	}
	public void setNgay(Date ngay) {
		this.ngay = ngay;
	}
	@Override
	public String toString() {
		return "BaoHiem [loaiBH=" + loaiBH + ", maBH=" + maBH + ", ngay="
				+ ngay + ", tenBH=" + tenBH + "]";
	}
	
}
