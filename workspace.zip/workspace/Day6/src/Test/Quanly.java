package Test;

import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;

import java.util.Scanner;
import java.util.zip.DataFormatException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Quanly {
	public static void main(String[] args) throws ParseException{
		DataAccess db= new DataAccess();
		if(db.getConnect()!=null)
			System.out.println("thanh cong");
		else System.out.println("that bai");
		
		System.out.println("============ add new =============");
		
		Scanner input=new Scanner(System.in);
		System.out.println("nhap ma bao hiem: ");
		String ma=input.nextLine();
		
		System.out.println("Nhap ten bao hiem");
		String ten=input.nextLine();
		
		System.out.println("Nhap loai bh");
		boolean loai=Boolean.parseBoolean(input.nextLine());
		System.out.println("Nhap ngay: ");
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		Date date = df.parse((input.nextLine()));
		
		BaoHiem bh1= new BaoHiem(ma, ten, loai,date);
		if(db.addnew(bh1)==true)
			System.out.println("them thanh cong");
			else
				System.out.println("that bai");
			
		
//		System.out.println("=========== delete =========");
//		System.out.println("nhap ma bao hiem muon xoa");
//		String ma1=input.nextLine();
//		if(db.delete(ma1)==true)
//			System.out.println("xoa thanh cong");
//		else 
//			System.out.println("xoa that bai");
//		
//		System.out.println("======= tim ======");
//		System.out.println("Nhap ma muon tim");
//		String ma2=input.nextLine();
//		ArrayList<BaoHiem> ds = db.getDanhSach(ma2);
//		for (BaoHiem item : ds) {
//			System.out.println(item.toString());
//			
//		}
//		db.addUseRs();
		
	}
	
}
