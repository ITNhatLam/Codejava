package Test;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class DataAccess {
	Connection sqlcon=null;
	Statement stmt=null;
	PreparedStatement pstmt=null;
	CallableStatement callstmt=null;
	ResultSet rs=null;
	ArrayList<BaoHiem> ds;
	public Connection getConnect(){
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			sqlcon=DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=Test; username=sa; password=12345678");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sqlcon;
	}
	public boolean addnew(BaoHiem bh)
	{
		String sql="Insert into BaoHiem values('"+bh.getMaBH()+"','"+bh.getTenBH()+"','"+bh.isLoaiBH()+"','"+bh.getNgay()+"')";
		try
		{
			stmt=getConnect().createStatement();
			stmt.executeUpdate(sql);
			return true;
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		}
		return false;
	}
	public boolean delete(String name) throws SQLException
	{
		String sql="delete from BaoHiem where MaBH=?";
		try {
			getConnect().setAutoCommit(false);
			pstmt=getConnect().prepareStatement(sql);
			pstmt.setString(1,name);
			pstmt.executeUpdate();
			getConnect().commit();
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			getConnect().rollback();
		}
		getConnect().setAutoCommit(true);
		return false;
	}
//	public ArrayList<BaoHiem> getDanhSach(String name)
//	{
//		try {
//			callstmt=getConnect().prepareCall("{call ds_bh(?)}");
//			callstmt.setString(1, name);
//			rs=callstmt.executeQuery();
//			BaoHiem bh;
//			ds = new ArrayList<BaoHiem>();
//			while(rs.next())
//			{
//				bh=new BaoHiem(rs.getString("MaBH"), rs.getString("TenBH"));
//				ds.add(bh);
//			}
//			
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//		return ds;
//	}
//public void updateUseRs(){
//		
//		try {
//			stmt = getConnect().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
//                    ResultSet.CONCUR_UPDATABLE);
//			rs = stmt.executeQuery("Select MaBH, TenBH from BaoHiem");
//			
//			rs.beforeFirst();
//			//STEP 7: Extract data from result set
//			while(rs.next()){
//				//Retrieve by column name
//				String newTenBH = rs.getString("");
//				rs.( "Tuoi", newTenBH );
//				rs.updateRow();
//			}
//			System.out.println("List result set showing new ages...");
//			//printRs(rs);
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//	}
	public void addUseRs() throws SQLException {
		try {
			stmt = getConnect().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
			        ResultSet.CONCUR_UPDATABLE);
			rs = stmt.executeQuery("Select MaBH, TenBH from BaoHiem");
			System.out.println("Inserting a new record...");
			getConnect().setAutoCommit(false);
		      rs.moveToInsertRow();
		      rs.updateString("MaBH","1234");
		      rs.updateString("TenBH","tu vong");
		      getConnect().commit();
		      
		      //Commit row
		      rs.insertRow();

		      System.out.println("List result set showing new set...");
		      printRs(rs);
		      //getConnect().setAutoCommit(true);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			getConnect().rollback();
		}
		
		getConnect().setAutoCommit(true);
		
	}
private void printRs(ResultSet rs2) {
	// TODO Auto-generated method stub
	
}
	
}
