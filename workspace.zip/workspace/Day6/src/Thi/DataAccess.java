package Thi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.util.Scanner;

public class DataAccess {
	Scanner input=new Scanner(System.in);
	Connection sqlcon=null;
	Statement stmt=null;
	ResultSet rs=null;
	public Connection getConnect(){
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			sqlcon=DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=Thi_1707; username=sa; password=12345678");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sqlcon;
	}
	public void addUngVienCoKN( UngVienCoKN uv1){
		String sql = "Insert into UngVienCoKinhNghiem values('"+uv1.getFullname()+"','"+uv1.getBirthday()+"',"+uv1.getPhone()+",'"+uv1.getEmail()+"','"+uv1.getCandidate_type()+"','"+uv1.getCanidate_count()+"','"+uv1.getSoNamKN()+"','"+uv1.getKyNangCM()+"','"+uv1.getNgoaiNgu()+"')";
		try {
			stmt=getConnect().createStatement();
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

