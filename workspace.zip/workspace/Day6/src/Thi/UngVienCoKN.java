package Thi;



public class UngVienCoKN extends UngVien{
	private int soNamKN;
	private String kyNangCM;
	private String ngoaiNgu;
	public UngVienCoKN(String fullname, String birthday, String phone,
			String email, int candidateType, int canidateCount, int soNamKN,
			String kyNangCM, String ngoaiNgu) {
		super(fullname, birthday, phone, email, candidateType, canidateCount);
		this.soNamKN = soNamKN;
		this.kyNangCM = kyNangCM;
		this.ngoaiNgu = ngoaiNgu;
	}
	public int getSoNamKN() {
		return soNamKN;
	}
	public void setSoNamKN(int soNamKN) {
		this.soNamKN = soNamKN;
	}
	public String getKyNangCM() {
		return kyNangCM;
	}
	public void setKyNangCM(String kyNangCM) {
		this.kyNangCM = kyNangCM;
	}
	public String getNgoaiNgu() {
		return ngoaiNgu;
	}
	public void setNgoaiNgu(String ngoaiNgu) {
		this.ngoaiNgu = ngoaiNgu;
	}
	@Override
	public void Showme() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public String toString() {
		return "UngVienCoKN [kyNangCM=" + kyNangCM + ", ngoaiNgu=" + ngoaiNgu
				+ ", soNamKN=" + soNamKN + "]";
	}
	
}
