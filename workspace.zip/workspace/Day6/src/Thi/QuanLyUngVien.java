package Thi;


import java.util.Scanner;

public class QuanLyUngVien {
	public static void main(String[] args) {
		DataAccess db= new DataAccess();
		if(db.getConnect()!=null)
			System.out.println("Ket noi thanh cong");
		else
			System.out.println("Ket noi that bai");
		
		Scanner input=new Scanner(System.in);
		System.out.println("Nhap ho ten: ");
		String hoten=input.nextLine();
		System.out.println("Nhap ngay sinh: ");
		String ngaysinh= input.nextLine();
		System.out.println("Nhap sdt: ");
		String phone=input.nextLine();
		System.out.println("Nhap email: ");
		String email=input.nextLine();
		System.out.println("Nhap so nam kinh nghiem: ");
		int sonam=Integer.parseInt(input.nextLine());
		System.out.println("Nhap ky nang chuyen mon: ");
		String kynang=input.nextLine();
		System.out.println("Nhap ngoai ngu: ");
		String ngng=input.nextLine();
		UngVienCoKN uv1=new UngVienCoKN(hoten, ngaysinh, phone, email, '0', '1', sonam, kynang, ngng);
		db.addUngVienCoKN(uv1);
	}
}
