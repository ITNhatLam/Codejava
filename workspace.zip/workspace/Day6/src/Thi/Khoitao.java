package Thi;

public class Khoitao {

}
