package Thi;

import java.util.Date;

public class UngVienTotNghiep extends UngVien{
	private Date thoiGianTN;
	private String truongTN;
	public Date getThoiGianTN() {
		return thoiGianTN;
	}
	public void setThoiGianTN(Date thoiGianTN) {
		this.thoiGianTN = thoiGianTN;
	}
	public String getTruongTN() {
		return truongTN;
	}
	public void setTruongTN(String truongTN) {
		this.truongTN = truongTN;
	}
	public UngVienTotNghiep(String fullname, String birthday, String phone,
			String email, int candidateType, int canidateCount,
			Date thoiGianTN, String truongTN) {
		super(fullname, birthday, phone, email, candidateType, canidateCount);
		this.thoiGianTN = thoiGianTN;
		this.truongTN = truongTN;
	}
	@Override
	public String toString() {
		return "UngVienTotNghiep [thoiGianTN=" + thoiGianTN + ", truongTN="
				+ truongTN + "]";
	}
	@Override
	public void Showme() {
		// TODO Auto-generated method stub
		
	}
	
}
