package Thi;



public class SinhVienTT extends UngVien{
	private String chuyenNganh;
	private String hocKy;
	private String truong;
	public SinhVienTT(String fullname, String birthday, String phone,
			String email, int candidateType, int canidateCount,
			String chuyenNganh, String hocKy, String truong) {
		super(fullname, birthday, phone, email, candidateType, canidateCount);
		this.chuyenNganh = chuyenNganh;
		this.hocKy = hocKy;
		this.truong = truong;
	}
	public String getChuyenNganh() {
		return chuyenNganh;
	}
	public void setChuyenNganh(String chuyenNganh) {
		this.chuyenNganh = chuyenNganh;
	}
	public String getHocKy() {
		return hocKy;
	}
	public void setHocKy(String hocKy) {
		this.hocKy = hocKy;
	}
	public String getTruong() {
		return truong;
	}
	public void setTruong(String truong) {
		this.truong = truong;
	}
	@Override
	public String toString() {
		return "SinhVienTT [chuyenNganh=" + chuyenNganh + ", hocKy=" + hocKy
				+ ", truong=" + truong + "]";
	}
	@Override
	public void Showme() {
		// TODO Auto-generated method stub
		
	}
	
}
