package Thi;



public abstract class UngVien {
	private String fullname;
	private String birthday;
	private String phone;
	private String email;
	private int candidate_type;
	private int canidate_count;
	public UngVien(String fullname, String birthday, String phone,
			String email, int candidateType, int canidateCount) {
		super();
		this.fullname = fullname;
		this.birthday = birthday;
		this.phone = phone;
		this.email = email;
		candidate_type = candidateType;
		canidate_count = canidateCount;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getCandidate_type() {
		return candidate_type;
	}
	public void setCandidate_type(int candidateType) {
		candidate_type = candidateType;
	}
	public int getCanidate_count() {
		return canidate_count;
	}
	public void setCanidate_count(int canidateCount) {
		canidate_count = canidateCount;
	}
	@Override
	public String toString() {
		return "Candidate [birthday=" + birthday + ", candidate_type="
				+ candidate_type + ", canidate_count=" + canidate_count
				+ ", email=" + email + ", fullname=" + fullname + ", phone="
				+ phone + "]";
	}
	public abstract void Showme();
}
