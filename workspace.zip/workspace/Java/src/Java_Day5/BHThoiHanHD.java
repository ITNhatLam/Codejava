package Java_Day5;

import java.util.Date;

public class BHThoiHanHD extends BaoHiem {
	private Date tGKetThuc;
	private String spBHDiKem;
	public BHThoiHanHD(String tenGoiBH, String thoiHanDong, int mucPhiDong,
			String mucDich, boolean cachThucDong, Date thoiGianBD,
			Date tGKetThuc, String spBHDiKem) {
		super(tenGoiBH, thoiHanDong, mucPhiDong, mucDich, cachThucDong,
				thoiGianBD);
		this.tGKetThuc = tGKetThuc;
		this.spBHDiKem = spBHDiKem;
	}
	public Date gettGKetThuc() {
		return tGKetThuc;
	}
	public void settGKetThuc(Date tGKetThuc) {
		this.tGKetThuc = tGKetThuc;
	}
	public String getSpBHDiKem() {
		return spBHDiKem;
	}
	public void setSpBHDiKem(String spBHDiKem) {
		this.spBHDiKem = spBHDiKem;
	}
	public String toString() {
		return "BHThoiHanHD [spBHDiKem=" + spBHDiKem + ", tGKetThuc="
				+ tGKetThuc + "]";
	}
	
}
