package Java_Day5;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;


public class Quanly {
	public static void main(String[] args) throws ParseException {
		DataAccessFromDB db = new DataAccessFromDB();
		if (db.getConnect() != null)
			System.out.println("Ket noi Ok");
		else
			System.out.println("That bai");

		Scanner input = new Scanner(System.in);
		
		System.out.println("Nhap ten goi bao hiem: ");
		String ten = input.nextLine();
		
		System.out.println("Nhap thoi han dong: ");
		String thoihan = input.nextLine();
		
		System.out.println("Nhap muc phi: ");
		int mucphi = Integer.parseInt(input.nextLine());
		
		System.out.println("Nhap muc dich: ");
		String mucdich = input.nextLine();
		
		System.out.println("Nhap cach thuc dong: ");
		boolean cachthuc=Boolean.parseBoolean(input.nextLine());
		DateFormat df=new SimpleDateFormat("MM/dd/yyyy");
		System.out.println("Nhap ngay bat dau: ");
		Date ngaybd = df.parse(input.nextLine());

		BaoHiem bh = new BaoHiem(ten,thoihan,mucphi,mucdich,cachthuc,ngaybd);
		if(db.addNewBH(bh)==true)
			System.out.println("Insert OK");
		else System.out.println("no ok");
	}

	
}
