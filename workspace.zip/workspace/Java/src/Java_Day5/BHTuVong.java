package Java_Day5;

import java.util.Date;

public class BHTuVong extends BaoHiem{
	private Boolean tHDongBH;
	private int tGToiThieuTG;
	public BHTuVong(String tenGoiBH, String thoiHanDong, int mucPhiDong,
			String mucDich, boolean cachThucDong, Date thoiGianBD,
			Boolean tHDongBH, int tGToiThieuTG) {
		super(tenGoiBH, thoiHanDong, mucPhiDong, mucDich, cachThucDong,
				thoiGianBD);
		this.tHDongBH = tHDongBH;
		this.tGToiThieuTG = tGToiThieuTG;
	}
	public Boolean gettHDongBH() {
		return tHDongBH;
	}
	public void settHDongBH(Boolean tHDongBH) {
		this.tHDongBH = tHDongBH;
	}
	public int gettGToiThieuTG() {
		return tGToiThieuTG;
	}
	public void settGToiThieuTG(int tGToiThieuTG) {
		this.tGToiThieuTG = tGToiThieuTG;
	}
	public String toString() {
		return "BHTuVong [tGToiThieuTG=" + tGToiThieuTG + ", tHDongBH="
				+ tHDongBH + "]";
	}
	
}
