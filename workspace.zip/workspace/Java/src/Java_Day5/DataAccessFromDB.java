package Java_Day5;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
public class DataAccessFromDB {
	Connection sqlcon=null;
	Statement stmt=null;
	/**
	 * Connect to Database
	 * @return
	 */
	public Connection getConnect(){
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			try {
				sqlcon=DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=Java_day5; username=sa; password=12345678");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sqlcon;
	}
	/**
	 * add new BaoHiem
	 */
	public boolean addNewBH(BaoHiem bh){
		
		
		String sql="Insert into BaoHiem values('"+bh.getTenGoiBH()+"','"+bh.getThoiHanDong()+"','"+bh.getMucPhiDong()+"','"+bh.getMucDich()+"','"+bh.getCachThucDong()+"','"+bh.getThoiGianBD()+"')";
		try
		{
			stmt=getConnect().createStatement();
			stmt.executeQuery(sql);
			return true;
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		}
		return false;
	}
}
