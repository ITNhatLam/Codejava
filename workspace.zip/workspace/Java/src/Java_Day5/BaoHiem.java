package Java_Day5;

import java.util.Date;

public class BaoHiem {
	private String tenGoiBH;
	private String thoiHanDong;
	private int mucPhiDong;
	private String mucDich;
	private boolean cachThucDong;
	private Date thoiGianBD;
	public BaoHiem(String tenGoiBH, String thoiHanDong, int mucPhiDong,
			String mucDich, boolean cachThucDong, Date thoiGianBD) {
		super();
		this.tenGoiBH = tenGoiBH;
		this.thoiHanDong = thoiHanDong;
		this.mucPhiDong = mucPhiDong;
		this.mucDich = mucDich;
		this.cachThucDong = cachThucDong;
		this.thoiGianBD = thoiGianBD;
	}
	public BaoHiem() {
		// TODO Auto-generated constructor stub
	}
	public String getTenGoiBH() {
		return tenGoiBH;
	}
	public void setTenGoiBH(String tenGoiBH) {
		this.tenGoiBH = tenGoiBH;
	}
	public String getThoiHanDong() {
		return thoiHanDong;
	}
	public void setThoiHanDong(String thoiHanDong) {
		this.thoiHanDong = thoiHanDong;
	}
	public int getMucPhiDong() {
		return mucPhiDong;
	}
	public void setMucPhiDong(int mucPhiDong) {
		this.mucPhiDong = mucPhiDong;
	}
	public String getMucDich() {
		return mucDich;
	}
	public void setMucDich(String mucDich) {
		this.mucDich = mucDich;
	}
	public boolean getCachThucDong() {
		return cachThucDong;
	}
	public void setCachThucDong(boolean cachThucDong) {
		this.cachThucDong = cachThucDong;
	}
	public Date getThoiGianBD() {
		return thoiGianBD;
	}
	public void setThoiGianBD(Date thoiGianBD) {
		this.thoiGianBD = thoiGianBD;
	}
	public String toString() {
		return "BaoHiem [cachThucDong=" + cachThucDong + ", mucDich=" + mucDich
				+ ", mucPhiDong=" + mucPhiDong + ", tenGoiBH=" + tenGoiBH
				+ ", thoiGianBD=" + thoiGianBD + ", thoiHanDong=" + thoiHanDong
				+ "]";
	}
}

