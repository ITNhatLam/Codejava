package Java_Day5;

import java.util.Date;

public class BHSinhKy extends BaoHiem {
	private Date tGKetThuc;
	private Date tGTroCap;
	public BHSinhKy(String tenGoiBH, String thoiHanDong, int mucPhiDong,
			String mucDich, boolean cachThucDong, Date thoiGianBD,
			Date tGKetThuc, Date tGTroCap) {
		super(tenGoiBH, thoiHanDong, mucPhiDong, mucDich, cachThucDong,
				thoiGianBD);
		this.tGKetThuc = tGKetThuc;
		this.tGTroCap = tGTroCap;
	}
	public Date gettGKetThuc() {
		return tGKetThuc;
	}
	public void settGKetThuc(Date tGKetThuc) {
		this.tGKetThuc = tGKetThuc;
	}
	public Date gettGTroCap() {
		return tGTroCap;
	}
	public void settGTroCap(Date tGTroCap) {
		this.tGTroCap = tGTroCap;
	}
	public String toString() {
		return "BHSinhKy [tGKetThuc=" + tGKetThuc + ", tGTroCap=" + tGTroCap
				+ "]";
	}
	
}
