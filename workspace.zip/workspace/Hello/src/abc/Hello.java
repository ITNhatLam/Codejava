package abc;

public class Hello {
	public static void main(String[] arg){
		System.out.println("Hello");
		int i=1;
		i=i+3;
		System.out.println(i);
	}
}
