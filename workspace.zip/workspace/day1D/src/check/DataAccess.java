package check;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public  class DataAccess {
	static Connection sqlcon=null;
	static Statement stmt=null;
	static PreparedStatement pstmt= null;
	static ResultSet rs=null;
	public static Connection getConnect(){
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			sqlcon=DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=BanSach; username=sa; password=12345678");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sqlcon;
	}
	public static ResultSet getName(String name, String pass)
	{
		String sql="select * from TAIKHOAN where UserName=? and Password=?";
		try {
			pstmt=getConnect().prepareStatement(sql);
			pstmt.setString(1,name);
			pstmt.setString(2,pass);
			rs=pstmt.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rs;
	}
	public static ResultSet Ds_sach()
	{
		String sql="select * from Sach";
		try
		{
			pstmt=getConnect().prepareStatement(sql);
			rs=pstmt.executeQuery();
		}
		catch(SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rs;
	}
}

