package model.bo;

import java.util.ArrayList;

import model.bean.Sach;
import model.dao.SachDAO;

public class SachBO {
	SachDAO saDAO = new SachDAO();
	public ArrayList<Sach> getListSach()
	{
		return saDAO.getListSach();
	}
	public ArrayList<Sach> getListSach(String loaiSach){
		return saDAO.getListSach();
	}
	public void themSach(String maSach, String tenSach, String tacGia, String nhaCC, String hinhAnh) {
		saDAO.themSach(maSach, tenSach, tacGia, nhaCC, hinhAnh);
	}
	public Sach getThongTinSach(String maSach){
		return saDAO.getThongTinSach(maSach);
	}
	public void suaSach(String maSach, String tenSach, String loaiSach, String tacGia, String nhaCC, String hinhAnh) {
		saDAO.suaSach(maSach, tenSach, loaiSach, tacGia, nhaCC, hinhAnh);
	}
	public void xoaSach(String msv) {
		saDAO.xoaSach(msv);
	}
}
