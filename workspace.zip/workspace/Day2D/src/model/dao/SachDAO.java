package model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.bean.Loai;
import model.bean.Sach;
public class SachDAO {
	String url="jdbc:sqlserver://localhost:1433;databaseName=BanSach";
	String userName="sa";
	String password="12345678";
	Connection con;
	Statement stmt=null;
	void connectDB()
	{
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection(url, userName, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	public ArrayList<Sach> getListSach()
	{
		connectDB();
		String sql="select s.MaSach,s.TenSach,s.Tacgia,s.NhaCungCap,s.HinhAnh,l.TenLoai from Sach s inner join Loai l on s.LoaiSach=l.LoaiSach";
		ResultSet rs=null;
		try {
			stmt=con.createStatement();
			rs=stmt.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ArrayList<Sach> list= new ArrayList<Sach>();
		Sach sa;
		try {
			while(rs.next())
			{
				sa= new Sach();
				
				sa.setMaSach(rs.getString("MaSach"));
				sa.setTenSach(rs.getString("TenSach"));
				sa.setTacGia(rs.getString("Tacgia"));
				sa.setNhaCC(rs.getString("NhaCungCap"));
				sa.setHinhAnh(rs.getString("HinhAnh"));
				sa.setLoaiSach("LoaiSach");
				
				list.add(sa);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	public ArrayList<Sach> getListSach(String loaisach)
	{
		connectDB();
		String sql=String.format("select s.MaSach,s.TenSach,s.Tacgia,s.NhaCungCap,s.HinhAnh,l.TenLoai from Sach s inner join Loai l on s.LoaiSach=l.LoaiSach where LoaiSach=?",loaisach);
		ResultSet rs=null;
		try {
			stmt=con.createStatement();
			rs=stmt.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ArrayList<Sach> list= new ArrayList<Sach>();
		Sach sa;
		try {
			while(rs.next())
			{
				sa= new Sach();
				sa.setMaSach(rs.getString("MaSach"));
				sa.setTenSach(rs.getString("TenSach"));
				sa.setTacGia(rs.getString("Tacgia"));
				sa.setNhaCC(rs.getString("NhaCungCap"));
				sa.setHinhAnh(rs.getString("HinhAnh"));
				list.add(sa);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	public Sach getThongTinSach(String maSach) {
		connectDB();
		String sql=	String.format("SELECT MaSach, TenSach, LoaiSach, Tacgia,NhaCungCap, HinhAnh "+
					" FROM Sach WHERE MaSach = '%s'", maSach);
		ResultSet rs = null;
		try {
			Statement stmt = con.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		Sach sa = new Sach();
		try {
			while(rs.next()){
				sa.setMaSach(maSach);
				sa.setTenSach(rs.getString("TenSach"));
				sa.setLoaiSach(rs.getString("LoaiSach"));
				sa.setTacGia(rs.getString("Tacgia"));
				sa.setNhaCC(rs.getString("NhaCungCap"));
				sa.setHinhAnh(rs.getString("HinhAnh"));
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return sa;
	}
	public void themSach(String maSach, String tenSach, String tacGia, String nhaCC, String hinhAnh) {
		connectDB();
		String sql=	String.format("INSERT INTO Sach(MaSach,TenSach,Tacgia,NhaCungCap,HinhAnh) "+
					" VALUES ( '%s',N'%s',N'%s',N'%s','%s' )", maSach, tenSach, tacGia, nhaCC, hinhAnh);
		try {
			Statement stmt = con.createStatement();
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public void suaSach(String maSach, String tenSach, String loaiSach, String tacGia, String nhaCC, String hinhAnh) {
		connectDB();
		String sql=	String.format("UPDATE Sach "+
					" SET TenSach = N'%s', LoaiSach = %s, Tacgia = '%s',NhaCungCap='%s',HinhAnh='%s' " +
					" WHERE MaSach = '%s'", tenSach, loaiSach, tacGia, nhaCC,maSach);
		try {
			Statement stmt = con.createStatement();
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public void xoaSach(String msv) {
		connectDB();
		String sql=	String.format("DELETE FROM Sach WHERE MaSach = '%s'", msv);
		try {
			Statement stmt = con.createStatement();
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
